export default function Home() {
  return (
    <h1>Docs(White coding)</h1>
  );
}
