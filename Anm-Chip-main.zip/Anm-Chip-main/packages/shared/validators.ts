// File: packages/shared/validators.ts
// Zod validators aligned with TZ Document requirements

import { z } from 'zod';
import { validateISO11784Chip } from '../db';

// === ANIMAL VALIDATION ===
export const animalSchema = z.object({
  species: z.enum(['dog', 'cat', 'other']),
  sex: z.enum(['male', 'female', 'unknown']),
  birthDate: z.string().datetime().optional(),
  color: z.string().max(50),
  breed: z.string().max(100).optional(),
  sterilized: z.boolean().default(false),
  status: z.enum(['owned', 'stray', 'shelter', 'deceased']).default('owned'),
  
  // Uzbekistan-specific validations
  region: z.string().max(100).optional(),
  mahalla: z.string().max(100).optional(),
  
  // Owner reference
  ownerId: z.string().uuid().optional(),
}).refine((data) => {
  // Custom validation: Animal must have owner if status is 'owned'
  if (data.status === 'owned' && !data.ownerId) {
    return false;
  }
  return true;
}, {
  message: 'Owned animals must have an owner',
  path: ['ownerId'],
});

// === CHIP VALIDATION WITH ISO STANDARDS ===
export const chipSchema = z.object({
  id: z.string().length(15).regex(/^\d{15}$/),
  animalId: z.string().uuid(),
  clinicId: z.string().uuid(),
  scannerId: z.string().max(50).optional(),
}).refine((data) => {
  const validation = validateISO11784Chip(data.id);
  return validation.isValid;
}, {
  message: 'Invalid ISO 11784/11785 chip format',
  path: ['id'],
});

// === OWNER VALIDATION WITH ONEID INTEGRATION ===
export const ownerSchema = z.object({
  externalId: z.string().max(100), // OneID UUID
  name: z.string().min(2).max(255),
  phone: z.string().regex(/^\+998[0-9]{9}$/), // Uzbekistan phone format
  email: z.string().email().optional(),
  addressId: z.string().uuid().optional(),
  verified: z.boolean().default(false),
  consentFlags: z.object({
    sms: z.boolean().default(true),
    email: z.boolean().default(false),
    data_sharing: z.boolean().default(false),
  }).default({}),
});

// === BULK IMPORT VALIDATOR ===
export const bulkImportSchema = z.object({
  records: z.array(animalSchema).max(10000), // Max 10k records per import
  clinicId: z.string().uuid(),
  importType: z.enum(['vaccination', 'sterilization', 'registration']),
  
  // Deduplication settings
  deduplicateBy: z.enum(['microchip', 'owner_phone', 'animal_features']).default('microchip'),
  
  // Error handling
  onError: z.enum(['stop', 'skip', 'continue']).default('skip'),
}).refine((data) => {
  // Ensure microchip numbers are provided if deduplicating by microchip
  if (data.deduplicateBy === 'microchip') {
    return data.records.every(record => record.microchipNumber);
  }
  return true;
});
