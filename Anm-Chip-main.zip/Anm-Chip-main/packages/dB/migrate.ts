// File: packages/db/migrate.ts
// Migration system for Uzbekistan deployment

import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { Pool } from 'pg';
import fs from 'fs/promises';
import path from 'path';

export class DatabaseMigrator {
  
  static async runMigrations(env: 'development' | 'production' = 'development') {
    const pool = new Pool({
      host: process.env.DB_HOST,
      port: parseInt(process.env.DB_PORT || '5432'),
      database: process.env.DB_NAME,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      ssl: env === 'production' ? { rejectUnauthorized: false } : false,
    });
    
    const db = drizzle(pool);
    
    try {
      console.log('🚀 Starting database migrations...');
      
      // Run drizzle migrations
      await migrate(db, { migrationsFolder: './migrations' });
      
      // Run custom SQL migrations if any
      await this.runCustomMigrations(env);
      
      // Seed initial data for Uzbekistan
      if (env === 'development') {
        await this.seedDevelopmentData();
      }
      
      // Seed production reference data
      if (env === 'production') {
        await this.seedProductionReferenceData();
      }
      
      console.log('✅ Migrations completed successfully');
    } catch (error) {
      console.error('❌ Migration failed:', error);
      throw error;
    } finally {
      await pool.end();
    }
  }
  
  static async runCustomMigrations(env: string) {
    const customMigrationsDir = path.join(__dirname, 'custom-migrations');
    
    try {
      const files = await fs.readdir(customMigrationsDir);
      const migrationFiles = files
        .filter(f => f.endsWith('.sql'))
        .sort(); // Ensure sequential execution
      
      for (const file of migrationFiles) {
        console.log(`📄 Running custom migration: ${file}`);
        const sql = await fs.readFile(path.join(customMigrationsDir, file), 'utf-8');
        
        // Split by semicolon and execute each statement
        const statements = sql.split(';').filter(stmt => stmt.trim());
        
        const pool = new Pool({
          host: process.env.DB_HOST,
          port: parseInt(process.env.DB_PORT || '5432'),
          database: process.env.DB_NAME,
          user: process.env.DB_USER,
          password: process.env.DB_PASSWORD,
        });
        
        try {
          for (const statement of statements) {
            if (statement.trim()) {
              await pool.query(statement);
            }
          }
        } finally {
          await pool.end();
        }
      }
    } catch (error) {
      if (error.code !== 'ENOENT') {
        throw error;
      }
      // Directory doesn't exist, which is fine
    }
  }
  
  static async seedDevelopmentData() {
    console.log('🌱 Seeding development data for Uzbekistan...');
    
    const pool = new Pool({
      host: process.env.DB_HOST,
      port: parseInt(process.env.DB_PORT || '5432'),
      database: process.env.DB_NAME,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
    });
    
    const db = drizzle(pool);
    
    try {
      // Seed Tashkent regions and mahallas
      await this.seedUzbekistanRegions(db);
      
      // Seed sample clinics and organizations
      await this.seedSampleOrganizations(db);
      
      // Seed test animals with Uzbekistan-specific data
      await this.seedTestAnimals(db);
      
      console.log('✅ Development data seeded successfully');
    } finally {
      await pool.end();
    }
  }
  
  static async seedUzbekistanRegions(db: any) {
    const regions = [
      { id: 'tashkent', name: 'Toshkent Shahri', type: 'city' },
      { id: 'tashkent-region', name: 'Toshkent Viloyati', type: 'region' },
      { id: 'samarkand', name: 'Samarqand', type: 'region' },
      { id: 'bukhara', name: 'Buxoro', type: 'region' },
      { id: 'khorezm', name: 'Xorazm', type: 'region' },
      { id: 'andijan', name: 'Andijon', type: 'region' },
      { id: 'fergana', name: 'Fargʻona', type: 'region' },
      { id: 'namangan', name: 'Namangan', type: 'region' },
      { id: 'navoiy', name: 'Navoiy', type: 'region' },
      { id: 'jizzakh', name: 'Jizzax', type: 'region' },
      { id: 'sirdaryo', name: 'Sirdaryo', type: 'region' },
      { id: 'surkhandarya', name: 'Surxondaryo', type: 'region' },
      { id: 'kashkadarya', name: 'Qashqadaryo', type: 'region' },
      { id: 'karakalpakstan', name: 'Qoraqalpogʻiston', type: 'republic' },
    ];
    
    // Insert regions
    for (const region of regions) {
      await db.insert(schema.regions).values(region).onConflictDoNothing();
    }
    
    // Seed Tashkent mahallas (districts)
    const tashkentMahallas = [
      'Yunusobod', 'Mirzo Ulugʻbek', 'Yakkasaroy', 'Shayxontohur',
      'Olmazor', 'Bektemir', 'Mirobod', 'Sergeli', 'Chilonzor',
      'Uchtepa', 'Yangihayot'
    ];
    
    for (const mahalla of tashkentMahallas) {
      await db.insert(schema.mahallas).values({
        name: mahalla,
        regionId: 'tashkent',
        population: Math.floor(Math.random() * 50000) + 10000,
      }).onConflictDoNothing();
    }
  }
}
