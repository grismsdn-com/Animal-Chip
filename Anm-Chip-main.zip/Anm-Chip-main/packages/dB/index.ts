// File: packages/db/index.ts
// Database connection and query patterns

import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

// Configuration for Uzbekistan deployment
export const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'pet_chip',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  ssl: process.env.NODE_ENV === 'production' ? { 
    rejectUnauthorized: false,
    ca: process.env.DB_SSL_CA 
  } : false,
  
  // Connection pool settings for Uzbekistan traffic patterns
  max: 20, // Maximum connections
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
};

const pool = new Pool(dbConfig);
export const db = drizzle(pool, { schema });

// === TRANSACTION PATTERNS ===
export const transactional = async <T>(
  operation: (tx: typeof db) => Promise<T>
): Promise<T> => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const tx = drizzle(client, { schema });
    const result = await operation(tx);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

// === ANIMAL REGISTRATION WORKFLOW ===
export const registerAnimalWithChip = async (
  animalData: typeof schema.animals.$inferInsert,
  chipData: typeof schema.chips.$inferInsert,
  clinicId: string,
  userId: string
) => {
  return await transactional(async (tx) => {
    // 1. Insert animal
    const [animal] = await tx.insert(schema.animals)
      .values(animalData)
      .returning();
    
    // 2. Insert chip with ISO validation
    const chipWithVerification = {
      ...chipData,
      clinicId,
      verificationHash: await generateChipHash(chipData.id),
    };
    
    const [chip] = await tx.insert(schema.chips)
      .values(chipWithVerification)
      .returning();
    
    // 3. Create ownership record
    await tx.insert(schema.ownershipHistory)
      .values({
        animalId: animal.id,
        ownerId: animalData.ownerId,
        basis: 'registration',
        recordedBy: userId,
      });
    
    // 4. Log audit trail
    await tx.insert(schema.auditLogs).values({
      action: 'ANIMAL_REGISTRATION',
      entityType: 'animal',
      entityId: animal.id,
      userId,
      details: {
        microchipNumber: chip.id,
        clinicId,
        timestamp: new Date().toISOString(),
      },
    });
    
    return { animal, chip };
  });
};

// === CHIP VALIDATION UTILITY ===
export const validateISO11784Chip = (chipNumber: string): {
  isValid: boolean;
  manufacturer?: string;
  country?: string;
  animalCode?: string;
} => {
  // ISO 11784/11785 validation (15 digits)
  const isoPattern = /^(\d{3})(\d{3})(\d{9})$/;
  const match = chipNumber.match(isoPattern);
  
  if (!match) {
    return { isValid: false };
  }
  
  const [, manufacturerCode, countryCode, animalCode] = match;
  
  // Validate manufacturer code against Uzbekistan registry
  const validManufacturers = ['985', '986', '987']; // Example Uzbekistan codes
  
  return {
    isValid: validManufacturers.includes(manufacturerCode),
    manufacturer: manufacturerCode,
    country: countryCode,
    animalCode,
  };
};
