// File: packages/db/integrations/myGovUz.ts
// Integration workflows with Uzbekistan government systems

import axios from 'axios';
import { db } from '../index';
import { eq } from 'drizzle-orm';
import { owners } from '../schema';

export class MyGovUzIntegration {
  private readonly baseURL = 'https://integration.my.gov.uz/api/v1';
  private readonly apiKey = process.env.MYGOV_API_KEY;
  private readonly clientId = process.env.MYGOV_CLIENT_ID;
  
  // === ONEID AUTHENTICATION INTEGRATION ===
  async verifyOneIdUser(oneIdToken: string): Promise<{
    verified: boolean;
    userData?: OneIdUserData;
    error?: string;
  }> {
    try {
      // Call OneID verification endpoint
      const response = await axios.post(
        `${this.baseURL}/oneid/verify`,
        { token: oneIdToken },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Client-ID': this.clientId,
            'Content-Type': 'application/json',
          },
          timeout: 5000, // 5 second timeout
        }
      );
      
      if (response.data.verified) {
        // Map OneID response to our owner schema
        const userData: OneIdUserData = {
          externalId: response.data.userId,
          name: `${response.data.firstName} ${response.data.lastName}`,
          phone: response.data.phoneNumber,
          email: response.data.email,
          verified: true,
          oneIdProfile: response.data.profile,
        };
        
        // Check if user already exists
        const existingOwner = await db.query.owners.findFirst({
          where: eq(owners.externalId, userData.externalId),
        });
        
        if (!existingOwner) {
          // Create new owner record
          await db.insert(owners).values(userData);
        } else {
          // Update existing record
          await db.update(owners)
            .set({
              name: userData.name,
              phone: userData.phone,
              email: userData.email,
              syncedWithOneIdAt: new Date(),
            })
            .where(eq(owners.id, existingOwner.id));
        }
        
        return { verified: true, userData };
      }
      
      return { verified: false, error: 'OneID verification failed' };
    } catch (error) {
      console.error('OneID verification error:', error);
      return { 
        verified: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      };
    }
  }
  
  // === ADDRESS LOOKUP INTEGRATION ===
  async getAddressFromCadaster(addressId: string): Promise<AddressData> {
    // Integrate with Uzbekistan address cadaster system
    const response = await axios.get(
      `${this.baseURL}/address/${addressId}`,
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Client-ID': this.clientId,
        },
      }
    );
    
    return {
      region: response.data.region,
      district: response.data.district,
      mahalla: response.data.mahalla,
      street: response.data.street,
      houseNumber: response.data.houseNumber,
      latitude: response.data.latitude,
      longitude: response.data.longitude,
    };
  }
  
  // === BATCH SYNC WITH GOVERNMENT REGISTRY ===
  async syncWithGovernmentRegistry(batchSize: number = 100): Promise<SyncReport> {
    const unsyncedAnimals = await db.query.animals.findMany({
      where: (animals, { isNull }) => isNull(animals.govSyncedAt),
      limit: batchSize,
      with: {
        chip: true,
        ownershipHistory: {
          with: {
            owner: true,
          },
        },
      },
    });
    
    const results: Array<{ animalId: string; success: boolean; error?: string }> = [];
    
    for (const animal of unsyncedAnimals) {
      try {
        const payload = this.prepareGovPayload(animal);
        
        // Send to My.Gov.Uz API Manager
        await axios.post(
          `${this.baseURL}/animal-registry/register`,
          payload,
          {
            headers: {
              'Authorization': `Bearer ${this.apiKey}`,
              'Client-ID': this.clientId,
              'X-Correlation-ID': animal.id,
            },
          }
        );
        
        // Mark as synced
        await db.update(schema.animals)
          .set({ govSyncedAt: new Date() })
          .where(eq(schema.animals.id, animal.id));
        
        results.push({ animalId: animal.id, success: true });
      } catch (error) {
        results.push({ 
          animalId: animal.id, 
          success: false, 
          error: error.message 
        });
      }
    }
    
    return {
      total: unsyncedAnimals.length,
      successful: results.filter(r => r.success).length,
      failed: results.filter(r => !r.success).length,
      details: results,
    };
  }
}

// === WEBHOOK HANDLER FOR GOV NOTIFICATIONS ===
export async function handleGovWebhook(
  payload: GovWebhookPayload,
  signature: string
): Promise<boolean> {
  // Verify JWS signature from My.Gov.Uz
  const isValid = verifyJWSSignature(payload, signature, process.env.GOV_JWKS_URI);
  
  if (!isValid) {
    throw new Error('Invalid webhook signature');
  }
  
  // Check for idempotency (prevent duplicate processing)
  const existing = await db.query.webhookLogs.findFirst({
    where: eq(schema.webhookLogs.correlationId, payload.correlationId),
  });
  
  if (existing) {
    return true; // Already processed
  }
  
  // Process based on webhook type
  switch (payload.type) {
    case 'OWNER_VERIFICATION_UPDATE':
      await handleOwnerVerification(payload.data);
      break;
      
    case 'ADDRESS_UPDATE':
      await handleAddressUpdate(payload.data);
      break;
      
    case 'CLINIC_LICENSE_UPDATE':
      await handleClinicLicenseUpdate(payload.data);
      break;
      
    default:
      console.warn(`Unknown webhook type: ${payload.type}`);
  }
  
  // Log successful processing
  await db.insert(schema.webhookLogs).values({
    correlationId: payload.correlationId,
    type: payload.type,
    payload: payload.data,
    processedAt: new Date(),
  });
  
  return true;
}
