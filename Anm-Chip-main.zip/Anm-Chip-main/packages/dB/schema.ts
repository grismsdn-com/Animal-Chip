// File: packages/db/schema/index.ts
// Aligned with TZ Document Section 7: Data Model

import { pgTable, uuid, varchar, timestamp, boolean, jsonb, pgEnum } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import { createInsertSchema } from 'drizzle-zod';

// === ENUMS (as defined in TZ Document) ===
export const speciesEnum = pgEnum('species', ['dog', 'cat', 'other']);
export const sexEnum = pgEnum('sex', ['male', 'female', 'unknown']);
export const statusEnum = pgEnum('animal_status', ['owned', 'stray', 'shelter', 'deceased']);
export const orgTypeEnum = pgEnum('organization_type', ['clinic', 'shelter', 'municipality', 'agency']);
export const incidentTypeEnum = pgEnum('incident_type', ['bite', 'disease', 'wildlife', 'complaint']);
export const lostFoundTypeEnum = pgEnum('lost_found_type', ['lost', 'found']);

// === ANIMAL Table (Core Entity) ===
export const animals = pgTable('animals', {
  id: uuid('id').primaryKey().defaultRandom(),
  species: speciesEnum('species').notNull(),
  sex: sexEnum('sex').notNull().default('unknown'),
  birthDate: timestamp('birth_date'),
  color: varchar('color', { length: 50 }),
  breed: varchar('breed', { length: 100 }),
  sterilized: boolean('sterilized').default(false),
  status: statusEnum('status').notNull().default('owned'),
  
  // Timestamps for audit
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
  deletedAt: timestamp('deleted_at'),
});

// === CHIP Table (ISO 11784/11785 Compliance) ===
export const chips = pgTable('chips', {
  id: varchar('id', { length: 15 }).primaryKey(), // ISO 11784/11785 format: 15 digits
  animalId: uuid('animal_id').references(() => animals.id, { onDelete: 'cascade' }).notNull(),
  assignedAt: timestamp('assigned_at').notNull().defaultNow(),
  clinicId: uuid('clinic_id').references(() => organizations.id), // Foreign key to Organization
  scannerId: varchar('scanner_id', { length: 50 }),
  verificationHash: varchar('verification_hash', { length: 64 }).notNull(), // SHA-256 hash for integrity
  
  // ISO Standard Fields
  manufacturerCode: varchar('manufacturer_code', { length: 3 }), // First 3 digits of 15-digit code
  countryCode: varchar('country_code', { length: 3 }), // According to ISO 3166
  animalCode: varchar('animal_code', { length: 9 }), // Remaining 9 digits
});

// === OWNER Table (OneID Integration) ===
export const owners = pgTable('owners', {
  id: uuid('id').primaryKey().defaultRandom(),
  externalId: varchar('external_id', { length: 100 }).unique().notNull(), // OneID UUID
  name: varchar('name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 20 }).notNull(),
  email: varchar('email', { length: 255 }),
  addressId: uuid('address_id'), // Will reference external address service
  verified: boolean('verified').default(false),
  consentFlags: jsonb('consent_flags').default({ 
    sms: true, 
    email: false, 
    data_sharing: false 
  }),
  
  // Integration timestamps
  syncedWithOneIdAt: timestamp('synced_with_oneid_at'),
  lastVerificationAt: timestamp('last_verification_at'),
});

// === OWNERSHIP HISTORY (Audit Trail) ===
export const ownershipHistory = pgTable('ownership_history', {
  id: uuid('id').primaryKey().defaultRandom(),
  animalId: uuid('animal_id').references(() => animals.id).notNull(),
  ownerId: uuid('owner_id').references(() => owners.id).notNull(),
  fromDate: timestamp('from_date').notNull().defaultNow(),
  toDate: timestamp('to_date'), // NULL = current owner
  basis: varchar('basis', { length: 50 }).notNull(), // registration, transfer, found, shelter_release
  documents: jsonb('documents').default([]), // Array of document metadata
  
  // Audit fields
  recordedBy: uuid('recorded_by'), // User ID who recorded this
  ipAddress: inet('ip_address'), // For audit trail
  userAgent: text('user_agent'),
});

// === MEDICAL RECORDS ===
export const medicalRecords = pgTable('medical_records', {
  id: uuid('id').primaryKey().defaultRandom(),
  animalId: uuid('animal_id').references(() => animals.id).notNull(),
  type: varchar('type', { length: 50 }).notNull(), // vaccination, sterilization, treatment, examination
  date: timestamp('date').notNull(),
  vetId: uuid('vet_id').references(() => users.id), // From separate users table
  clinicId: uuid('clinic_id').references(() => organizations.id),
  notes: text('notes'),
  attachments: jsonb('attachments').default([]), // Array of file metadata
  
  // Specific fields for vaccinations
  vaccineType: varchar('vaccine_type', { length: 100 }),
  batchNumber: varchar('batch_number', { length: 50 }),
  nextDueDate: timestamp('next_due_date'),
  
  // TimescaleDB optimization for time-series queries
  recordedAt: timestamp('recorded_at').notNull().defaultNow(),
});

// === ORGANIZATIONS (RBAC Structure) ===
export const organizations = pgTable('organizations', {
  id: uuid('id').primaryKey().defaultRandom(),
  type: orgTypeEnum('type').notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  address: varchar('address', { length: 500 }),
  contacts: jsonb('contacts').notNull().default({}),
  
  // Integration with My.Gov.Uz
  govRegistrationNumber: varchar('gov_registration_number', { length: 50 }).unique(),
  verifiedByGov: boolean('verified_by_gov').default(false),
  
  // Operational fields
  isActive: boolean('is_active').default(true),
  region: varchar('region', { length: 100 }), // Tashkent, Samarkand, etc.
  mahalla: varchar('mahalla', { length: 100 }),
});

// === ZOD VALIDATION SCHEMAS ===
export const insertAnimalSchema = createInsertSchema(animals, {
  species: (schema) => schema.species.refine((val) => ['dog', 'cat', 'other'].includes(val)),
  microchipNumber: (schema) => schema.microchipNumber.pattern(/^[0-9]{15}$/),
});

// === RELATIONSHIPS ===
export const animalsRelations = relations(animals, ({ one, many }) => ({
  chip: one(chips, { fields: [animals.id], references: [chips.animalId] }),
  medicalRecords: many(medicalRecords),
  ownershipHistory: many(ownershipHistory),
}));

export const chipsRelations = relations(chips, ({ one }) => ({
  animal: one(animals, { fields: [chips.animalId], references: [animals.id] }),
  clinic: one(organizations, { fields: [chips.clinicId], references: [organizations.id] }),
}));
